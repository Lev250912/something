local composer = require("composer")
local scene = composer.newScene()
local widget = require("widget")
local keyboard = require("keyboard")

local fontRegular = "fonts/regular.otf"
local fontMedium = "fonts/medium.otf"

local webView 
local fullWebHeight 
local topBarHeight 

-- Высота клавиатуры (должна совпадать с bgHeight в keyboard.lua)
local keyboardHeight = 260 

function scene:create(event)
    local sceneGroup = self.view
    local cx = display.contentCenterX
    local cy = display.contentCenterY
    local w = display.actualContentWidth
    local h = display.actualContentHeight
    local top = display.screenOriginY
    local bottom = h + display.screenOriginY
    local left = display.screenOriginX
    
    local bg = display.newRect(sceneGroup, cx, cy, w, h)
    bg:setFillColor(1) 
    
    local toolbarH = 56
    local toolbarY = top + 28
    
    -- Вычисляем высоту верхней панели (с учетом "челки" и статус бара)
    topBarHeight = 56 + top 
    -- Полная высота браузера без клавиатуры
    fullWebHeight = h - topBarHeight
    
    local toolbar = display.newGroup()
    sceneGroup:insert(toolbar)
    toolbar.y = toolbarY
    
    local tbBg = display.newRect(toolbar, cx, 0, w, toolbarH)
    tbBg:setFillColor(1)
    
    local line = display.newRect(toolbar, cx, toolbarH/2, w, 1)
    line:setFillColor(0.9)

    local homeIcon = display.newImageRect(toolbar, "icons/home.png", 24, 24)
    if not homeIcon then homeIcon = display.newRect(toolbar, 0, 0, 20, 20) end
    homeIcon.x = left + 30
    homeIcon:setFillColor(0.35)
    
    local urlBarW = w - 140
    local urlBar = display.newGroup()
    toolbar:insert(urlBar)
    urlBar.x = cx - 10
    
    local urlBg = display.newRoundedRect(urlBar, 0, 0, urlBarW, 38, 19)
    urlBg:setFillColor(0.93, 0.93, 0.94)
    
    local lockIcon = display.newImageRect(urlBar, "icons/lock.png", 12, 12)
    if not lockIcon then lockIcon = display.newCircle(urlBar, -urlBarW/2 + 20, 0, 5) end
    lockIcon.x = -urlBarW/2 + 20
    lockIcon:setFillColor(0.4)
    
    local urlText = display.newText({
        parent = urlBar,
        text = "google.com",
        x = -urlBarW/2 + 40, y = 0,
        font = fontRegular, fontSize = 16
    })
    urlText.anchorX = 0
    urlText:setFillColor(0.2)
    
    local cursor = display.newRect(urlBar, 0, 0, 2, 20)
    cursor:setFillColor(0, 0.47, 1)
    cursor.alpha = 0
    
    local function updateCursor()
        cursor.x = urlText.x + urlText.width + 2
    end
    updateCursor()
    
    local tabsGroup = display.newGroup()
    toolbar:insert(tabsGroup)
    tabsGroup.x = w - 65
    
    local tabsIcon = display.newRoundedRect(tabsGroup, 0, 0, 20, 20, 5)
    tabsIcon:setFillColor(0, 0, 0, 0)
    tabsIcon.strokeWidth = 2
    tabsIcon:setStrokeColor(0.35)
    
    local tabsCount = display.newText({
        parent = tabsGroup, text = "1", x = 0, y = 0,
        font = fontMedium, fontSize = 12
    })
    tabsCount:setFillColor(0.35)
    
    local menuIcon = display.newImageRect(toolbar, "icons/more.png", 24, 24)
    if not menuIcon then 
        menuIcon = display.newGroup()
        for i=-1,1 do display.newCircle(menuIcon, 0, i*7, 2):setFillColor(0.35) end
        toolbar:insert(menuIcon)
    end
    menuIcon.x = w - 25
    menuIcon:setFillColor(0.35)
    
    local kb 
    local isEditing = false
    
    local function blinkCursor()
        transition.cancel("cursorBlink")
        cursor.alpha = 1
        transition.to(cursor, {tag="cursorBlink", time=500, alpha=1})
        transition.to(cursor, {tag="cursorBlink", delay=500, time=500, alpha=0, onComplete=blinkCursor})
    end
    
    local function stopCursor()
        transition.cancel("cursorBlink")
        cursor.alpha = 0
    end
    
    -- === ФУНКЦИЯ ИЗМЕНЕНИЯ РАЗМЕРА WEBVIEW ===
    local function setWebViewSize(keyboardOpen)
        if webView then
            -- Привязка anchorY = 0 важна, чтобы менять только height
            webView.anchorY = 0
            webView.y = topBarHeight
            
            if keyboardOpen then
                -- Уменьшаем высоту на высоту клавиатуры
                local newH = fullWebHeight - keyboardHeight * 2
                if newH < 0 then newH = 0 end 
                webView.height = newH
            else
                -- Возвращаем полную высоту
                webView.height = fullWebHeight
            end
        end
    end
    -- =========================================

    local function onKey(char)
        if urlText.text == "google.com" and isEditing then
             urlText.text = "" 
             isEditing = false
        end
        urlText.text = urlText.text .. char
        updateCursor()
    end
    
    local function onBackspace()
        local s = urlText.text
        local len = #s
        if len > 0 then
            local offset = len
            while offset > 0 do
                local b = string.byte(s, offset)
                if b >= 128 and b <= 191 then
                    offset = offset - 1
                else
                    break
                end
            end
            urlText.text = string.sub(s, 1, offset - 1)
            updateCursor()
        end
    end
    
    local function onEnter()
        kb:hide()
        stopCursor()
        setWebViewSize(false) -- Разворачиваем браузер обратно
        
        local url = urlText.text
        if url ~= "" then
            if not string.find(url, "http") then
                url = "https://" .. url
            end
            
            if not string.find(url, "%.") then
                 url = "https://www.google.com/search?q=" .. urlText.text
            end
            
            if webView then
                webView:request(url)
            end
        end
    end
    
    kb = keyboard.new({
        onKey = onKey,
        onBackspace = onBackspace,
        onEnter = onEnter
    })
    sceneGroup:insert(kb)
    kb.y = h + 300 
    
    homeIcon:addEventListener("tap", function()
        if webView then 
            kb:hide()
            stopCursor()
            setWebViewSize(false) -- Возврат размера при нажатии "Домой"
            webView:request("https://google.com") 
            urlText.text = "google.com"
            updateCursor()
        end
        return true
    end)
    
    urlBg:addEventListener("tap", function()
        isEditing = true
        kb:show()
        blinkCursor()
        setWebViewSize(true) -- Сжимаем браузер
        return true
    end)
end

local function onKey(event)
    if (event.keyName == "back" and event.phase == "up") then
        if webView then 
            if webView.canGoBack then
                webView:back()
                return true
            end
            webView.isVisible = false 
        end
        
        local screenCap = display.captureBounds(display.currentStage.contentBounds)
        screenCap.x, screenCap.y = display.contentCenterX, display.contentCenterY
        
        composer.gotoScene("home", {time=0})
        
        transition.to(screenCap, {
            time = 350, alpha = 0, xScale = 0.6, yScale = 0.6, transition = easing.outQuad,
            onComplete = function() display.remove(screenCap) end
        })
        return true
    end
    return false
end

function scene:show(event)
    local sceneGroup = self.view
    local phase = event.phase

    if ( phase == "will" ) then
        -- Создаем WebView с начальными координатами
        webView = native.newWebView(display.contentCenterX, topBarHeight, display.actualContentWidth, fullWebHeight)
        
        if webView then
            -- СРАЗУ задаем точку привязки сверху (0), чтобы ресайз работал корректно
            webView.anchorY = 0
            webView.y = topBarHeight
            
            webView:request("https://www.google.com/search?q=google") 
            
            webView:addEventListener("urlRequest", function(ev)
                if ev.type == "loaded" then
                end
            end)
        end
        
    elseif ( phase == "did" ) then
        Runtime:addEventListener("key", onKey)
    end
end

function scene:hide(event)
    local sceneGroup = self.view
    local phase = event.phase

    if ( phase == "will" ) then
        Runtime:removeEventListener("key", onKey)
        if webView then
            webView:removeSelf()
            webView = nil
        end
    end
end

scene:addEventListener("create", scene)
scene:addEventListener("show", scene)
scene:addEventListener("hide", scene)

return scene